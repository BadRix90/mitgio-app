export const firebaseConfig = {
  apiKey: "AIzaSyAwXxdMZ8PdCTi2Y3ZgIJTZ9l_FLtJR2N8",
  authDomain: "mitgio.firebaseapp.com",
  projectId: "mitgio",
  storageBucket: "mitgio.appspot.com",
  messagingSenderId: "318005083756",
  appId: "1:318005083756:web:4628ca78c127c502152249"
};